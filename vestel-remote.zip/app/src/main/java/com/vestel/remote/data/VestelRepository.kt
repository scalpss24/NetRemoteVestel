package com.vestel.remote.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

data class TvInfo(
    val friendlyName: String,
    val tvVersion: String,
    val ip: String,
    val mac: String? = null,
    val isOnline: Boolean = true
)

sealed class CommandResult {
    data class Success(val code: Int, val httpStatus: Int) : CommandResult()
    data class Error(val code: Int, val message: String) : CommandResult()
}

class VestelRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(2, TimeUnit.SECONDS)
        .readTimeout(2, TimeUnit.SECONDS)
        .writeTimeout(2, TimeUnit.SECONDS)
        .build()

    private val xmlMediaType = "text/xml; charset=utf-8".toMediaType()

    /**
     * Отправляет команду клавиши на телевизор Vestel.
     * Использует двойную доставку (Dual-Delivery):
     * 1. SmartCenter HTTP POST на порт 56789 (официальный протокол Vestel)
     * 2. Сырой TCP сокет на порт 4660 (мгновенный сетевой интерфейс MB130)
     */
    suspend fun sendKey(ip: String, code: Int): CommandResult = withContext(Dispatchers.IO) {
        // Отправка через прямой сокет 4660 (не блокируя основной поток)
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, 4660), 800)
                socket.soTimeout = 800
                val writer = OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8)
                writer.write("$code\r\n")
                writer.write("<?xml version=\"1.0\" ?><remote><key code=\"$code\"/></remote>\r\n")
                writer.flush()
            }
        } catch (_: Exception) {
            // Сокет 4660 может быть недоступен на некоторых прошивках, продолжаем HTTP
        }

        // Отправка через HTTP SmartCenter на порт 56789
        val url = "http://$ip:56789/apps/SmartCenter"
        val xmlPayload = "<?xml version=\"1.0\" ?><remote><key code=\"$code\"/></remote>"
        val requestBody = xmlPayload.toRequestBody(xmlMediaType)

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .addHeader("Content-Type", "text/xml; charset=utf-8")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful || response.code == 201 || response.code == 200) {
                    CommandResult.Success(code, response.code)
                } else {
                    CommandResult.Error(code, "HTTP ${response.code}: ${response.message}")
                }
            }
        } catch (e: IOException) {
            CommandResult.Error(code, e.localizedMessage ?: "Сетевая ошибка при отправке команды")
        } catch (e: Exception) {
            CommandResult.Error(code, e.localizedMessage ?: "Неизвестная ошибка")
        }
    }

    /**
     * Проверяет доступность телевизора и получает информацию из dd.xml
     * Эндпоинт: http://<IP>:56790/dd.xml
     */
    suspend fun fetchDeviceInfo(ip: String): TvInfo? = withContext(Dispatchers.IO) {
        val url = "http://$ip:56790/dd.xml"
        val request = Request.Builder()
            .url(url)
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val friendlyName = extractTag(body, "friendlyName") ?: "Vestel Smart TV"
                    val tvVersion = extractTag(body, "tv_version") ?: "MB130_VESTEL"
                    val mac = extractTag(body, "mac")
                    TvInfo(friendlyName = friendlyName, tvVersion = tvVersion, ip = ip, mac = mac, isOnline = true)
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Отправляет Wake-on-LAN Magic Packet для включения ТВ из режима ожидания
     */
    suspend fun sendWakeOnLan(macAddress: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val cleanMac = macAddress.replace(":", "").replace("-", "")
            if (cleanMac.length != 12) return@withContext false

            val macBytes = ByteArray(6)
            for (i in 0 until 6) {
                macBytes[i] = cleanMac.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }

            val bytes = ByteArray(6 + 16 * 6)
            for (i in 0 until 6) {
                bytes[i] = 0xFF.toByte()
            }
            for (i in 0 until 16) {
                System.arraycopy(macBytes, 0, bytes, 6 + i * 6, 6)
            }

            DatagramSocket().use { socket ->
                socket.broadcast = true
                val packet = DatagramPacket(bytes, bytes.size, InetAddress.getByName("255.255.255.255"), 9)
                socket.send(packet)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun extractTag(xml: String, tag: String): String? {
        val pattern = Pattern.compile("<$tag>(.*?)</$tag>", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(xml)
        return if (matcher.find()) matcher.group(1)?.trim() else null
    }
}

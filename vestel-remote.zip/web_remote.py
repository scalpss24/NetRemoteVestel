"""
Веб-пульт для Vestel MB130 (прокси-сервер для тестирования с ПК или смартфона)
Запуск: python web_remote.py
Откройте в браузере телефона или ПК: http://<IP_компьютера>:8080 (например, http://192.168.1.2:8080)
"""
import http.server
import socketserver
import urllib.request
import urllib.error
import json
import sys

PORT = 8080

HTML_PAGE = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>Vestel Remote</title>
<style>
  body {
    background-color: #121212;
    color: #e0e0e0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin: 0;
    padding: 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    user-select: none;
  }
  .container {
    width: 100%;
    max-width: 360px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .header-card {
    background: #1e1e1e;
    border-radius: 12px;
    padding: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.5);
  }
  .input-group {
    display: flex;
    gap: 8px;
    margin-bottom: 8px;
  }
  input[type="text"] {
    flex: 1;
    background: #2a2a2a;
    border: 1px solid #444;
    color: #fff;
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 15px;
  }
  button {
    background: #2c2c2e;
    color: #fff;
    border: none;
    border-radius: 8px;
    padding: 10px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    touch-action: manipulation;
    transition: background 0.1s, transform 0.05s;
  }
  button:active {
    background: #3a3a3c;
    transform: scale(0.96);
  }
  .btn-primary { background: #007aff; }
  .btn-primary:active { background: #0056b3; }
  .btn-danger { background: #ff3b30; }
  .btn-danger:active { background: #c62828; }
  .btn-green { background: #34c759; }
  .btn-green:active { background: #248a3d; }
  .status-bar {
    font-size: 12px;
    color: #aaa;
    min-height: 18px;
    text-align: center;
  }
  .grid-3 {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
  }
  .grid-2 {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
  }
  .dpad {
    display: grid;
    grid-template-areas:
      ". up ."
      "left ok right"
      ". down .";
    gap: 8px;
    margin: 8px 0;
  }
  .dpad button { height: 48px; }
  .dpad-up { grid-area: up; }
  .dpad-down { grid-area: down; }
  .dpad-left { grid-area: left; }
  .dpad-right { grid-area: right; }
  .dpad-ok { grid-area: ok; background: #0a84ff; font-weight: bold; }
  .section-title {
    font-size: 11px;
    color: #777;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 4px;
  }
</style>
</head>
<body>
<div class="container">
  <div class="header-card">
    <div class="input-group">
      <input type="text" id="tvIp" placeholder="IP ТВ (например 192.168.1.5)" value="">
      <button class="btn-green" onclick="testPing()">Инфо</button>
    </div>
    <div id="status" class="status-bar">Введите реальный IP ТВ</div>
  </div>

  <div class="grid-3">
    <button class="btn-danger" onclick="sendCmd(1012)">⏻ Вкл/Выкл</button>
    <button onclick="sendCmd(1013)">🔇 Mute</button>
    <button onclick="sendCmd(1015)">ℹ️ Инфо</button>
  </div>

  <div class="grid-2">
    <button class="btn-primary" onclick="sendCmd(1016)">VOL +</button>
    <button class="btn-primary" onclick="sendCmd(1032)">CH ▲</button>
    <button class="btn-primary" onclick="sendCmd(1017)">VOL −</button>
    <button class="btn-primary" onclick="sendCmd(1033)">CH ▼</button>
  </div>

  <div class="dpad">
    <button class="dpad-up" onclick="sendCmd(1020)">▲</button>
    <button class="dpad-left" onclick="sendCmd(1021)">◄</button>
    <button class="dpad-ok" onclick="sendCmd(1053)">OK</button>
    <button class="dpad-right" onclick="sendCmd(1022)">►</button>
    <button class="dpad-down" onclick="sendCmd(1019)">▼</button>
  </div>

  <div class="grid-3">
    <button onclick="sendCmd(1010)">⮌ Назад</button>
    <button onclick="sendCmd(1046)">🏠 Smart/Home</button>
    <button onclick="sendCmd(1037)">✖ Выход</button>
  </div>

  <div class="grid-2">
    <button onclick="sendCmd(1048)">☰ Меню</button>
    <button onclick="sendCmd(1056)">📺 Источник</button>
  </div>

  <div class="section-title">Цифры</div>
  <div class="grid-3">
    <button onclick="sendCmd(1001)">1</button>
    <button onclick="sendCmd(1002)">2</button>
    <button onclick="sendCmd(1003)">3</button>
    <button onclick="sendCmd(1004)">4</button>
    <button onclick="sendCmd(1005)">5</button>
    <button onclick="sendCmd(1006)">6</button>
    <button onclick="sendCmd(1007)">7</button>
    <button onclick="sendCmd(1008)">8</button>
    <button onclick="sendCmd(1009)">9</button>
    <div></div>
    <button onclick="sendCmd(1000)">0</button>
    <div></div>
  </div>
</div>

<script>
  // Автосохранение IP в localStorage
  const ipInput = document.getElementById('tvIp');
  const statusEl = document.getElementById('status');
  ipInput.value = localStorage.getItem('vestel_tv_ip') || '192.168.1.5';

  ipInput.addEventListener('change', () => {
    localStorage.setItem('vestel_tv_ip', ipInput.value.trim());
  });

  async function sendCmd(code) {
    const ip = ipInput.value.trim();
    if (!ip) {
      statusEl.textContent = 'Укажите IP телевизора!';
      statusEl.style.color = '#ff453a';
      return;
    }
    localStorage.setItem('vestel_tv_ip', ip);
    statusEl.textContent = `Отправка ${code}...`;
    statusEl.style.color = '#aaa';

    try {
      const resp = await fetch('/api/send', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ ip, code })
      });
      const data = await resp.json();
      if (data.ok) {
        statusEl.textContent = `Команда ${code} принята (HTTP ${data.status})`;
        statusEl.style.color = '#30d158';
      } else {
        statusEl.textContent = `Ошибка: ${data.error}`;
        statusEl.style.color = '#ff453a';
      }
    } catch (e) {
      statusEl.textContent = `Сбой сети: ${e.message}`;
      statusEl.style.color = '#ff453a';
    }
  }

  async function testPing() {
    const ip = ipInput.value.trim();
    if (!ip) {
      statusEl.textContent = 'Укажите IP телевизора!';
      statusEl.style.color = '#ff453a';
      return;
    }
    statusEl.textContent = `Проверка связи с http://${ip}:56790/dd.xml...`;
    statusEl.style.color = '#aaa';

    try {
      const resp = await fetch('/api/info', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ ip })
      });
      const data = await resp.json();
      if (data.ok) {
        statusEl.textContent = `ТВ обнаружен! ${data.name || 'Vestel Smart TV'}`;
        statusEl.style.color = '#30d158';
      } else {
        statusEl.textContent = `Не отвечает: ${data.error}`;
        statusEl.style.color = '#ff453a';
      }
    } catch (e) {
      statusEl.textContent = `Ошибка: ${e.message}`;
      statusEl.style.color = '#ff453a';
    }
  }
</script>
</body>
</html>
"""

class RequestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/' or self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(HTML_PAGE.encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length)
        
        try:
            req = json.loads(post_data.decode('utf-8'))
        except Exception as e:
            self._send_json({'ok': False, 'error': f'Invalid JSON: {e}'}, 400)
            return

        if self.path == '/api/send':
            ip = req.get('ip')
            code = req.get('code')
            if not ip or not code:
                self._send_json({'ok': False, 'error': 'Missing ip or code'}, 400)
                return

            # Прямая отправка в TCP сокет 4660
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(0.8)
                s.connect((ip, 4660))
                s.sendall(f"{code}\r\n".encode())
                s.close()
            except Exception:
                pass

            # Если команда включения/выключения - отправим также WOL
            if str(code) == '1012':
                try:
                    mac_bytes = bytes.fromhex('7054B405D743')
                    magic = b'\xff' * 6 + mac_bytes * 16
                    ws = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    ws.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                    ws.sendto(magic, ('255.255.255.255', 9))
                    ws.close()
                except Exception:
                    pass

            url = f"http://{ip}:56789/apps/SmartCenter"
            xml_body = f'<?xml version="1.0" ?><remote><key code="{code}"/></remote>'.encode('utf-8')
            http_req = urllib.request.Request(url, data=xml_body, headers={'Content-Type': 'text/xml; charset=utf-8'})

            try:
                with urllib.request.urlopen(http_req, timeout=3) as response:
                    status = response.getcode()
                    self._send_json({'ok': True, 'status': status, 'code': code})
            except urllib.error.HTTPError as e:
                self._send_json({'ok': True, 'status': e.code, 'code': code})
            except Exception as e:
                self._send_json({'ok': False, 'error': str(e)})

        elif self.path == '/api/info':
            ip = req.get('ip')
            if not ip:
                self._send_json({'ok': False, 'error': 'Missing ip'}, 400)
                return

            url = f"http://{ip}:56790/dd.xml"
            try:
                with urllib.request.urlopen(url, timeout=3) as response:
                    xml_data = response.read().decode('utf-8', errors='ignore')
                    name = "Vestel TV"
                    if "<friendlyName>" in xml_data:
                        name = xml_data.split("<friendlyName>")[1].split("</friendlyName>")[0]
                    self._send_json({'ok': True, 'name': name})
            except Exception as e:
                self._send_json({'ok': False, 'error': str(e)})
        else:
            self.send_response(404)
            self.end_headers()

    def _send_json(self, data, code=200):
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def log_message(self, format, *args):
        # Компактный лог в консоль
        sys.stderr.write(f"[{self.log_date_time_string()}] {args[0]} - {args[1]}\n")

if __name__ == '__main__':
    port = PORT
    with socketserver.TCPServer(("", port), RequestHandler) as httpd:
        print(f"=== Веб-пульт Vestel запущен на порту {port} ===")
        print(f"Локально: http://localhost:{port}")
        print(f"С телефона в Wi-Fi сети: http://<IP_этого_ПК>:{port}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nОстановка сервера.")
